<?php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/stagekitwp-core-blocks.php';

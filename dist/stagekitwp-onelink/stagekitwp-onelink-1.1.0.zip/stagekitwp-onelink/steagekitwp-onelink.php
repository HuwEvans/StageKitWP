<?php
/**
 * Plugin Name: StageKitWP OneLink
 * Plugin URI:  https://miltonplayers.com
 * Description: Multi-style link aggregator for Milton Players Theatre Group integrated with StageKitWP ecosystem content.
 * Version:     1.1.0
 * Author:      Milton Players Theatre Group
 * Text Domain: stagekitwp-onelink
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class StageKitWP_OneLink {

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_shortcode('stagekit_onelink', array($this, 'render_onelink_tree'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
    }

    public function add_admin_menu() {
        add_submenu_page(
            'stagekitwp',
            'StageKitWP OneLink Settings',
            'OneLink Aggregator',
            'manage_options',
            'stagekit-onelink',
            array($this, 'render_admin_page')
        );
    }

    public function register_settings() {
        register_setting('sk_onelink_group', 'sk_onelink_settings');
    }

    public function render_admin_page() {
        $options = get_option('sk_onelink_settings', array());
        $current_style = $options['display_style'] ?? 'classic';
        ?>
        <div class="wrap">
            <h1>StageKitWP OneLink Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('sk_onelink_group');
                do_settings_sections('sk_onelink_group');
                ?>

                <h2>Display Style & Theme</h2>
                <p>Choose how your link tree renders on the front-end.</p>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="sk_display_style">Layout View</label></th>
                        <td>
                            <select name="sk_onelink_settings[display_style]" id="sk_display_style">
                                <option value="classic" <?php selected($current_style, 'classic'); ?>>Classic List (Full-Width Buttons)</option>
                                <option value="grid" <?php selected($current_style, 'grid'); ?>>Compact 2-Column Grid</option>
                                <option value="hero" <?php selected($current_style, 'hero'); ?>>Featured Hero Card + List</option>
                                <option value="glass" <?php selected($current_style, 'glass'); ?>>Minimal Glassmorphism</option>
                                <option value="spotlight" <?php selected($current_style, 'spotlight'); ?>>Stage Spotlight (Dark & Gold Theatre Theme)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Brand Colors</th>
                        <td>
                            <label style="margin-right:15px;">Accent / Primary Color:<br>
                                <input type="color" name="sk_onelink_settings[primary_color]" value="<?php echo esc_attr($options['primary_color'] ?? '#d97706'); ?>">
                            </label>
                            <label>Button Background:<br>
                                <input type="color" name="sk_onelink_settings[btn_bg_color]" value="<?php echo esc_attr($options['btn_bg_color'] ?? '#111827'); ?>">
                            </label>
                        </td>
                    </tr>
                </table>

                <h2>Automated Ecosystem Links</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Current Season Tickets</th>
                        <td>
                            <label>
                                <input type="checkbox" name="sk_onelink_settings[enable_tickets]" value="1" <?php checked(1, $options['enable_tickets'] ?? 0); ?>>
                                Auto-include active season show ticket links
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Season Subscription</th>
                        <td>
                            <label>
                                <input type="checkbox" name="sk_onelink_settings[enable_subscription]" value="1" <?php checked(1, $options['enable_subscription'] ?? 0); ?>>
                                Auto-include Season Subscription Link
                            </label><br>
                            <input type="url" class="regular-text" name="sk_onelink_settings[subscription_url]" placeholder="https://example.com/subscriptions" value="<?php echo esc_attr($options['subscription_url'] ?? ''); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Auditions Page</th>
                        <td>
                            <label>
                                <input type="checkbox" name="sk_onelink_settings[enable_auditions]" value="1" <?php checked(1, $options['enable_auditions'] ?? 0); ?>>
                                Auto-include active Auditions listing
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Events Page</th>
                        <td>
                            <label>
                                <input type="checkbox" name="sk_onelink_settings[enable_events]" value="1" <?php checked(1, $options['enable_events'] ?? 0); ?>>
                                Auto-include Main Events listing
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Media Section</th>
                        <td>
                            <label>
                                <input type="checkbox" name="sk_onelink_settings[enable_media]" value="1" <?php checked(1, $options['enable_media'] ?? 0); ?>>
                                Include Link to Media Gallery
                            </label><br>
                            <input type="url" class="regular-text" name="sk_onelink_settings[media_url]" placeholder="https://example.com/media" value="<?php echo esc_attr($options['media_url'] ?? ''); ?>">
                        </td>
                    </tr>
                </table>

                <h2>Social Media Slugs</h2>
                <table class="form-table">
                    <tr>
                        <th>Instagram Handle</th>
                        <td><input type="text" name="sk_onelink_settings[social_instagram]" value="<?php echo esc_attr($options['social_instagram'] ?? ''); ?>" placeholder="miltonplayers"></td>
                    </tr>
                    <tr>
                        <th>Facebook Page</th>
                        <td><input type="text" name="sk_onelink_settings[social_facebook]" value="<?php echo esc_attr($options['social_facebook'] ?? ''); ?>" placeholder="MiltonPlayers"></td>
                    </tr>
                    <tr>
                        <th>YouTube Channel</th>
                        <td><input type="text" name="sk_onelink_settings[social_youtube]" value="<?php echo esc_attr($options['social_youtube'] ?? ''); ?>" placeholder="@miltonplayers"></td>
                    </tr>
                </table>

                <h2>Custom Extra Links</h2>
                <div id="sk-custom-links-container">
                    <?php
                    $custom_links = $options['custom_links'] ?? array();
                    if (!empty($custom_links)) :
                        foreach ($custom_links as $index => $link) : ?>
                            <p>
                                <input type="text" name="sk_onelink_settings[custom_links][<?php echo $index; ?>][title]" value="<?php echo esc_attr($link['title']); ?>" placeholder="Title">
                                <input type="url" name="sk_onelink_settings[custom_links][<?php echo $index; ?>][url]" value="<?php echo esc_attr($link['url']); ?>" placeholder="https://">
                            </p>
                        <?php endforeach;
                    else: ?>
                        <p>
                            <input type="text" name="sk_onelink_settings[custom_links][0][title]" placeholder="Title">
                            <input type="url" name="sk_onelink_settings[custom_links][0][url]" placeholder="https://">
                        </p>
                    <?php endif; ?>
                </div>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function render_onelink_tree($atts) {
        $options = get_option('sk_onelink_settings', array());
        
        // Allow shortcode attribute override: [stagekit_onelink style="spotlight"]
        $atts = shortcode_atts(array(
            'style' => $options['display_style'] ?? 'classic'
        ), $atts, 'stagekit_onelink');

        $style = sanitize_html_class($atts['style']);
        $links = array();

        // 1. Subscription
        if (!empty($options['enable_subscription']) && !empty($options['subscription_url'])) {
            $links[] = array(
                'title' => '🎟️ Season Subscriptions',
                'url'   => $options['subscription_url'],
                'type'  => 'featured'
            );
        }

        // 2. Season Show Tickets (CPT query)
        if (!empty($options['enable_tickets'])) {
            $shows = new WP_Query(array(
                'post_type'      => 'stagekit_show',
                'posts_per_page' => 5,
                'post_status'    => 'publish'
            ));
            if ($shows->have_posts()) {
                while ($shows->have_posts()) {
                    $shows->the_post();
                    $ticket_url = get_post_meta(get_the_ID(), '_sk_ticket_url', true) ?: get_permalink();
                    $links[] = array(
                        'title' => '🎭 Tickets: ' . get_the_title(),
                        'url'   => $ticket_url,
                        'type'  => 'show'
                    );
                }
                wp_reset_postdata();
            }
        }

        // 3. Auditions
        if (!empty($options['enable_auditions'])) {
            $links[] = array('title' => '📣 Auditions & Casting', 'url' => home_url('/auditions/'), 'type' => 'standard');
        }

        // 4. Events
        if (!empty($options['enable_events'])) {
            $links[] = array('title' => '📅 Full Events Calendar', 'url' => home_url('/events/'), 'type' => 'standard');
        }

        // 5. Media Section
        if (!empty($options['enable_media']) && !empty($options['media_url'])) {
            $links[] = array('title' => '🖼️ Photos & Media Gallery', 'url' => $options['media_url'], 'type' => 'standard');
        }

        // 6. Custom Links
        if (!empty($options['custom_links']) && is_array($options['custom_links'])) {
            foreach ($options['custom_links'] as $custom) {
                if (!empty($custom['title']) && !empty($custom['url'])) {
                    $links[] = array('title' => $custom['title'], 'url' => $custom['url'], 'type' => 'custom');
                }
            }
        }

        ob_start();
        ?>
        <div class="sk-onelink-wrapper sk-view-<?php echo esc_attr($style); ?>">
            <div class="sk-onelink-header">
                <h2>Milton Players Theatre Group</h2>
                <p class="sk-subtitle">Live Theatre & Season Content Hub</p>
            </div>

            <?php if ($style === 'hero' && !empty($links)) : 
                $featured = array_shift($links); ?>
                <div class="sk-hero-card">
                    <span class="sk-hero-badge">Featured</span>
                    <h3><?php echo esc_html($featured['title']); ?></h3>
                    <a href="<?php echo esc_url($featured['url']); ?>" class="sk-hero-btn" target="_blank" rel="noopener">Explore Now</a>
                </div>
            <?php endif; ?>

            <div class="sk-onelink-tree">
                <?php foreach ($links as $link) : ?>
                    <a href="<?php echo esc_url($link['url']); ?>" class="sk-link-card sk-type-<?php echo esc_attr($link['type']); ?>" target="_blank" rel="noopener">
                        <span class="sk-link-title"><?php echo esc_html($link['title']); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <div class="sk-onelink-socials">
                <?php if (!empty($options['social_instagram'])) : ?>
                    <a href="https://instagram.com/<?php echo esc_attr($options['social_instagram']); ?>" target="_blank" rel="noopener">Instagram</a>
                <?php endif; ?>
                <?php if (!empty($options['social_facebook'])) : ?>
                    <a href="https://facebook.com/<?php echo esc_attr($options['social_facebook']); ?>" target="_blank" rel="noopener">Facebook</a>
                <?php endif; ?>
                <?php if (!empty($options['social_youtube'])) : ?>
                    <a href="https://youtube.com/<?php echo esc_attr($options['social_youtube']); ?>" target="_blank" rel="noopener">YouTube</a>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function enqueue_styles() {
        $options = get_option('sk_onelink_settings', array());
        $primary = esc_attr($options['primary_color'] ?? '#d97706');
        $btn_bg  = esc_attr($options['btn_bg_color'] ?? '#111827');

        wp_register_style('sk-onelink-style', false);
        wp_enqueue_style('sk-onelink-style');

        $custom_css = "
            /* Core Base Styles */
            .sk-onelink-wrapper { max-width: 480px; margin: 0 auto; padding: 24px; text-align: center; font-family: system-ui, -apple-system, sans-serif; }
            .sk-onelink-header h2 { margin: 0 0 4px; font-size: 1.5rem; font-weight: 700; }
            .sk-subtitle { margin: 0 0 20px; opacity: 0.75; font-size: 0.9rem; }
            .sk-link-card { display: flex; align-items: center; justify-content: center; text-decoration: none; font-weight: 600; transition: all 0.25s ease; }
            .sk-onelink-socials { margin-top: 24px; display: flex; justify-content: center; gap: 16px; font-size: 0.9rem; }

            /* 1. VIEW: Classic List */
            .sk-view-classic .sk-link-card { background: {$btn_bg}; color: #ffffff; padding: 14px 20px; margin-bottom: 12px; border-radius: 8px; }
            .sk-view-classic .sk-link-card:hover { transform: translateY(-2px); filter: brightness(1.15); }
            .sk-view-classic .sk-type-featured { background: {$primary}; }

            /* 2. VIEW: Compact Grid */
            .sk-view-grid .sk-onelink-tree { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
            .sk-view-grid .sk-link-card { background: {$btn_bg}; color: #ffffff; padding: 18px 12px; border-radius: 10px; min-height: 70px; text-align: center; font-size: 0.88rem; }
            .sk-view-grid .sk-type-featured { grid-column: span 2; background: {$primary}; }

            /* 3. VIEW: Hero Card + List */
            .sk-view-hero .sk-hero-card { background: {$primary}; color: #fff; padding: 20px; border-radius: 14px; margin-bottom: 16px; text-align: left; }
            .sk-view-hero .sk-hero-badge { background: rgba(0,0,0,0.2); font-size: 0.75rem; padding: 3px 8px; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
            .sk-view-hero .sk-hero-card h3 { margin: 8px 0 12px; font-size: 1.25rem; }
            .sk-view-hero .sk-hero-btn { display: inline-block; background: #fff; color: #111; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-weight: bold; }
            .sk-view-hero .sk-link-card { background: #f3f4f6; color: #1f2937; padding: 12px 16px; margin-bottom: 8px; border-radius: 8px; border: 1px solid #e5e7eb; }

            /* 4. VIEW: Minimal Glassmorphism */
            .sk-view-glass { background: rgba(255, 255, 255, 0.4); backdrop-filter: blur(12px); border-radius: 16px; border: 1px solid rgba(255, 255, 255, 0.3); }
            .sk-view-glass .sk-link-card { background: rgba(255, 255, 255, 0.65); color: #111827; padding: 14px 20px; margin-bottom: 10px; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.8); }
            .sk-view-glass .sk-link-card:hover { background: rgba(255, 255, 255, 0.95); }

            /* 5. VIEW: Stage Spotlight (Theatre Dark Mode) */
            .sk-view-spotlight { background: #0d0d11; color: #f3f4f6; border-radius: 16px; border: 1px solid #27272a; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
            .sk-view-spotlight .sk-onelink-header h2 { color: #f59e0b; text-shadow: 0 0 10px rgba(245, 158, 11, 0.3); }
            .sk-view-spotlight .sk-link-card { background: #18181b; color: #f3f4f6; padding: 14px 20px; margin-bottom: 12px; border-radius: 8px; border: 1px solid #3f3f46; }
            .sk-view-spotlight .sk-link-card:hover { border-color: #f59e0b; color: #f59e0b; box-shadow: 0 0 12px rgba(245, 158, 11, 0.2); }
            .sk-view-spotlight .sk-type-featured { background: linear-gradient(135deg, #b45309, #d97706); border: none; color: #fff; }
        ";
        wp_add_inline_style('sk-onelink-style', $custom_css);
    }
}

new StageKitWP_OneLink();
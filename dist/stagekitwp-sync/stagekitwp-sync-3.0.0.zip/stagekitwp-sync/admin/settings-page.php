<?php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/stagekitwp-sync-settings-page.php';
